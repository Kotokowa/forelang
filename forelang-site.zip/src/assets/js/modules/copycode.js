
// copycode.js - Prism toolbar copy helper (Prism plugin already provides button)
(() => {
  // Nothing needed if using Prism toolbar plugin from CDN
})();
