---
title: 正则变换与哈密顿-雅可比方程
date: 2025-12-01
layout: layouts/post.njk
tags: [post, 力学]
cover: /forelang/assets/img/cover-demo2.jpg
summary: 正则变换与哈密顿-雅可比方程 可作为力学中广义坐标 qα, vα与pα 与广义势 pφ,vα伴随不同的坐标变换的形式，解释…
---

[toc]

## 1. 引言
这里是内容……